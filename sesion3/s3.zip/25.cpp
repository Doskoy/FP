#include <iostream>
using namespace std;

int main(){

	int diferencia; 
	char caracter; 
	char caracter_minus;

	diferencia = 'a' - 'A'; 

	cout << "Introduzca una letra en mayuscula: ";
	cin >> caracter; 

	caracter_minus = caracter + diferencia; 

	cout << "La letra en minuscula es: " << caracter_minus << endl;



}